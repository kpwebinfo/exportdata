@echo off
cd /d "%~dp0"
if not exist "venv\Scripts\python.exe" ( echo Please run 1_setup.bat first. & pause & exit /b 1 )
"venv\Scripts\python.exe" import_data.py %*
echo.
pause

"""Shared definitions: database columns, header aliases and file locations.

If a new file has a column header the importer does not recognise, add it to ALIAS below.
"""
import os
import re
from pathlib import Path

BASE = Path(__file__).resolve().parent
DB_PATH = Path(os.environ.get("EXPORT_DB", BASE / "data" / "exports.db"))
INCOMING = BASE / "data" / "incoming"

# (database column, display name, kind)   kind: text | date | int | num
COLUMNS = [
    ("sb_no", "Shipping Bill No.", "text"),
    ("sb_date", "Shipping Bill Date", "date"),
    ("month", "Month", "text"),
    ("year", "Year", "int"),
    ("indian_port", "Indian Port", "text"),
    ("port_code", "Port Code", "text"),
    ("mode", "Mode", "text"),
    ("iec", "IEC", "text"),
    ("exporter_name", "Exporter Names", "text"),
    ("exporter_address", "Exporter Address & state", "text"),
    ("contact_no", "Contact No.", "text"),
    ("email", "Email id", "text"),
    ("importer_name", "Importer Names", "text"),
    ("importer_address", "Importer Address", "text"),
    ("foreign_port", "Foreign Port", "text"),
    ("foreign_country", "Foreign Country", "text"),
    ("hs_code", "HS Code", "text"),
    ("hs4", "4 Digit HS Code", "text"),
    ("chapter", "Chapter", "text"),
    ("product_description", "Product Description", "text"),
    ("quantity", "Quantity", "num"),
    ("uqc", "Unit Quantity", "text"),
    ("unit_rate_fc", "Unit Rate in FC", "num"),
    ("currency", "Currency", "text"),
    ("total_value_fc", "Total Value in FC", "num"),
    ("unit_rate_inr", "Unit Rate in INR", "num"),
    ("fob_inr", "FOB in INR", "num"),
    ("drawback", "Drawback", "num"),
    ("invoice_no", "Invoice No.", "text"),
    ("item_no", "Item Number", "num"),
    ("type", "Type", "text"),
    ("fob_usd", "FOB USD", "num"),
    ("exporter_pin", "Exporter PIN", "text"),
    ("unit_rate_with_fob", "Unit Rate with FOB", "num"),
    ("per_unit_fob", "Per Unit FOB", "num"),
    ("fob_fc", "FOB FC", "num"),
    ("ex_ex_rate", "Ex Ex Rate", "num"),
    ("exchange_rate", "Exchange Rate", "num"),
    ("contact_person", "Contact Person Name", "text"),
    ("source_file", "Source File", "text"),
    ("source_row", "Source Row", "int"),
    ("data_notes", "Data Notes", "text"),
]
DB_BY_DISPLAY = {d: db for db, d, _ in COLUMNS}
DISPLAY_BY_DB = {db: d for db, d, _ in COLUMNS}
KIND = {d: k for _, d, k in COLUMNS}


def norm_header(c):
    return re.sub(r"\s+", " ", str(c)).strip().upper()


# normalised header in a raw file  ->  display name (or a special key starting with "_")
ALIAS = {
    "SHIPPING BILL NO.": "Shipping Bill No.", "SB NO": "Shipping Bill No.", "SHIPPING BILL NO": "Shipping Bill No.",
    "SHIPPING BILL DATE": "Shipping Bill Date", "SB DATE": "Shipping Bill Date",
    "MONTH": "Month", "YEAR": "Year",
    "INDIAN PORT": "Indian Port", "PORT OF LOADING": "Indian Port", "PORT": "Indian Port",
    "PORT CODE": "Port Code", "MODE": "Mode", "MODE OF PORT": "Mode",
    "IEC": "IEC", "EXPORTER ID": "IEC",
    "EXPORTER NAMES": "Exporter Names", "EXPORTER NAME": "Exporter Names",
    "EXPORTER ADDRESS & STATE": "_addr_full", "EXPORTER ADDRESS": "_addr_part",
    "EXPORTER CITY/ STATE": "_city_state", "EXPORTER CITY/STATE": "_city_state",
    "EXPORTER CITY/ STATE.1": "_ignore", "EXPORTER CITY/ STATE2": "_ignore",
    "CONTACT NO.": "Contact No.", "EXPORTER PHONE": "Contact No.",
    "EMAIL ID": "Email id", "EXPORTER EMAIL": "Email id",
    "IMPORTER NAMES": "Importer Names", "IMPORTER NAME": "Importer Names",
    "IMPORTER ADDRESS": "Importer Address",
    "FOREIGN PORT": "Foreign Port", "PORT OF DISCHARGE": "Foreign Port",
    "FOREIGN COUNTRY": "Foreign Country", "COUNTRY OF ORIGIN": "Foreign Country",
    "HS CODE": "HS Code", "RITC": "HS Code", "RITC CODE": "HS Code",
    "4 DIGIT HS CODE": "4 Digit HS Code", "4 DIGIT": "4 Digit HS Code",
    "CHAPTER": "Chapter", "2 DIGIT": "Chapter", "CH": "Chapter",
    "PRODUCT DESCRIPTION": "Product Description", "RITC DISCRIPTION": "Product Description",
    "QUANTITY": "Quantity", "UNIT QUANTITY": "Unit Quantity", "UQC": "Unit Quantity",
    "UNIT RATE IN FC": "Unit Rate in FC", "UNT PRICE FC": "Unit Rate in FC",
    "CURRENCY": "Currency",
    "TOTAL VALUE IN FC": "Total Value in FC", "INV VALUE FC": "Total Value in FC",
    "UNIT RATE IN INR": "Unit Rate in INR", "UNT PRICE INR": "Unit Rate in INR",
    "FOB IN INR": "FOB in INR", "FOB INR": "FOB in INR",
    "DRAWBACK": "Drawback", "DWARBACK": "Drawback",
    "INVOICE NO.": "Invoice No.", "INVOICE NO": "Invoice No.",
    "ITEM NUMBER": "Item Number",
    "TYPE": "Type", "FOB USD": "FOB USD", "EXPORTER PIN": "_pin",
    "UNIT RATE WITH FOB": "Unit Rate with FOB", "PER UNT FOB": "Per Unit FOB", "FOB FC": "FOB FC",
    "EX EX RATE": "Ex Ex Rate", "EXCHANGE RATE": "Exchange Rate", "CONTACT PERSON NAME": "Contact Person Name",
}
REQUIRED = ["Shipping Bill Date", "HS Code", "FOB in INR"]
PLACEHOLDERS = {"NA", "N/A", "NULL", "N?A", "N/A?", "NAN", "NONE"}
MONTHS = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"]

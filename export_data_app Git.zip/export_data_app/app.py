#!/usr/bin/env python3
"""Export Data Explorer - local web app.   Start with:  python app.py   (then open http://127.0.0.1:5000)"""
import csv
import datetime as dt
import io
import os
import sqlite3
import tempfile
import threading
import webbrowser

from flask import Flask, Response, g, jsonify, request, send_file, send_from_directory

from schema import BASE, COLUMNS, DB_PATH, MONTHS

app = Flask(__name__, static_folder=str(BASE / "static"), static_url_path="/static")
app.json.sort_keys = False

XLSX_LIMIT = 250_000          # max rows for an Excel download (Excel itself allows ~1,048,000)

# ----------------------------------------------------------------------------------------- database
def db():
    if "db" not in g:
        if not DB_PATH.exists():
            raise FileNotFoundError("no_db")
        g.db = sqlite3.connect(DB_PATH.as_uri() + "?mode=ro", uri=True)
        g.db.execute("PRAGMA cache_size=-200000")
    return g.db


@app.teardown_appcontext
def close_db(_):
    d = g.pop("db", None)
    if d is not None:
        d.close()


def q(sql, params=()):
    return db().execute(sql, params).fetchall()


@app.errorhandler(FileNotFoundError)
def no_db(_):
    return jsonify(error="no_db",
                   message="No database yet. Put your files in data/incoming and run the import step."), 503


# simple result cache, cleared automatically when the database file changes
_cache, _cache_stamp = {}, [None]


def cached(fn):
    def wrapper(*a, **k):
        stamp = DB_PATH.stat().st_mtime if DB_PATH.exists() else None
        if stamp != _cache_stamp[0]:
            _cache.clear()
            _cache_stamp[0] = stamp
        key = (request.path, tuple(sorted((x, tuple(v)) for x, v in request.args.lists())))
        if key not in _cache:
            if len(_cache) > 400:
                _cache.clear()
            _cache[key] = fn(*a, **k)
        return _cache[key]
    wrapper.__name__ = fn.__name__
    return wrapper


# ------------------------------------------------------------------------------------------ filters
def terms(name):
    """';'-separated search terms from a text box, upper-cased."""
    return [t.strip().upper() for t in request.args.get(name, "").split(";") if t.strip()]


def where():
    c, p = [], []

    def in_(col, vals):
        if vals:
            c.append(f"{col} IN ({','.join('?' * len(vals))})")
            p.extend(vals)

    gl = request.args.getlist
    in_("year", [int(v) for v in gl("year") if v.isdigit()])
    in_("month", [v.upper() for v in gl("month")])
    in_("mode", [v.upper() for v in gl("mode")])
    in_("chapter", gl("chapter"))
    in_("foreign_country", [v.upper() for v in gl("country")])
    in_("indian_port", [v.upper() for v in gl("port")])
    hs = [v.strip() for v in gl("hs") if v.strip()]
    if hs:
        c.append("(" + " OR ".join("hs_code LIKE ?" for _ in hs) + ")")
        p.extend(v + "%" for v in hs)
    for arg, col in (("exporter", "exporter_name"), ("importer", "importer_name")):
        t = terms(arg)
        if t:
            c.append("(" + " OR ".join(f"instr({col}, ?) > 0" for _ in t) + ")")
            p.extend(t)
    t = terms("product")
    if t:
        c.append("(" + " OR ".join("instr(upper(product_description), ?) > 0" for _ in t) + ")")
        p.extend(t)
    if request.args.get("date_from"):
        c.append("sb_date >= ?"); p.append(request.args["date_from"])
    if request.args.get("date_to"):
        c.append("sb_date <= ?"); p.append(request.args["date_to"])
    return (" WHERE " + " AND ".join(c)) if c else "", p


def and_(w, extra):
    return (w + " AND " if w else " WHERE ") + extra


# ------------------------------------------------------------------------------------------- pages
@app.route("/")
def index():
    return send_from_directory(app.static_folder, "index.html")


# --------------------------------------------------------------------------------------------- API
@app.route("/api/options")
@cached
def options():
    years = [{"v": r[0], "n": r[1]} for r in q("SELECT year, COUNT(*) FROM shipments WHERE year IS NOT NULL GROUP BY year ORDER BY year")]
    modes = [{"v": r[0], "n": r[1]} for r in q("SELECT mode, COUNT(*) FROM shipments WHERE mode IS NOT NULL GROUP BY mode ORDER BY 2 DESC")]
    chapters = [{"v": r[0], "n": r[1]} for r in q("SELECT chapter, COUNT(*) FROM shipments WHERE chapter IS NOT NULL GROUP BY chapter ORDER BY chapter")]
    return jsonify(years=years, modes=modes, chapters=chapters, months=MONTHS)


@app.route("/api/kpis")
@cached
def kpis():
    w, p = where()
    r = q("SELECT COUNT(*), COALESCE(SUM(fob_inr),0), COUNT(DISTINCT exporter_name), COUNT(DISTINCT importer_name),"
          " COUNT(DISTINCT foreign_country), COUNT(DISTINCT indian_port), MIN(sb_date), MAX(sb_date)"
          " FROM shipments" + w, p)[0]
    return jsonify(records=r[0], fob=r[1], exporters=r[2], importers=r[3], countries=r[4], ports=r[5],
                   date_min=r[6], date_max=r[7])


@app.route("/api/trend")
@cached
def trend():
    w, p = where()
    rows = q("SELECT ym, COUNT(*), COALESCE(SUM(fob_inr),0) FROM shipments" + and_(w, "ym IS NOT NULL") + " GROUP BY ym ORDER BY ym", p)
    return jsonify(rows=[{"ym": r[0], "records": r[1], "fob": r[2]} for r in rows])


# group-by definitions for the ranking tables: expression, extra columns (label, sql)
RANK = {
    "exporter": ("exporter_name", [("Countries", "COUNT(DISTINCT foreign_country)"), ("IEC", "MAX(iec)")]),
    "importer": ("importer_name", [("Exporters", "COUNT(DISTINCT exporter_name)"), ("Country", "MAX(foreign_country)")]),
    "country": ("foreign_country", [("Exporters", "COUNT(DISTINCT exporter_name)"), ("Buyers", "COUNT(DISTINCT importer_name)")]),
    "port": ("indian_port", [("Code", "MAX(port_code)"), ("Exporters", "COUNT(DISTINCT exporter_name)")]),
    "foreign_port": ("foreign_port", [("Country", "MAX(foreign_country)"), ("Exporters", "COUNT(DISTINCT exporter_name)")]),
    "hs4": ("hs4", [("Exporters", "COUNT(DISTINCT exporter_name)"), ("Countries", "COUNT(DISTINCT foreign_country)")]),
    "hs8": ("hs_code", [("Exporters", "COUNT(DISTINCT exporter_name)"), ("Countries", "COUNT(DISTINCT foreign_country)")]),
    "product": ("product_description", [("HS code", "MAX(hs_code)"), ("Exporters", "COUNT(DISTINCT exporter_name)")]),
}


def common_desc(col, value, w="", p=()):
    """Most frequent product description for one HS code (free-text descriptions vary a lot)."""
    r = q(f"SELECT product_description FROM shipments{and_(w, f'{col} = ? AND product_description IS NOT NULL')}"
          " GROUP BY product_description ORDER BY COUNT(*) DESC LIMIT 1", list(p) + [value])
    return (r[0][0] if r else "") or ""


@app.route("/api/top")
@cached
def top():
    by = request.args.get("by", "country")
    if by not in RANK:
        return jsonify(error="bad 'by'"), 400
    expr, extras = RANK[by]
    limit = max(1, min(int(request.args.get("limit", 25)), 1000))
    order = "records" if request.args.get("sort") == "records" else "fob"
    w, p = where()
    w2 = and_(w, f"{expr} IS NOT NULL")
    tot = q("SELECT COUNT(*), COALESCE(SUM(fob_inr),0), COUNT(DISTINCT " + expr + ") FROM shipments" + w2, p)[0]
    sel = ", ".join(sql for _, sql in extras)
    rows = q(f"SELECT {expr}, COUNT(*) AS records, COALESCE(SUM(fob_inr),0) AS fob, {sel} FROM shipments{w2}"
             f" GROUP BY {expr} ORDER BY {order} DESC, records DESC LIMIT ?", p + [limit])
    out = [{"name": r[0], "records": r[1], "fob": r[2], "extra": list(r[3:])} for r in rows]
    labels = [l for l, _ in extras]
    if by in ("hs4", "hs8"):
        col = RANK[by][0]
        labels = labels + ["Most common description"]
        for o in out:
            o["extra"].append(common_desc(col, o["name"], w, p)[:90])
    return jsonify(by=by, total_records=tot[0], total_fob=tot[1], groups=tot[2], extra_labels=labels, rows=out)


TABLE_COLS = ["sb_date", "sb_no", "exporter_name", "importer_name", "foreign_country", "foreign_port", "indian_port",
              "mode", "hs_code", "product_description", "quantity", "uqc", "currency", "unit_rate_fc", "fob_inr",
              "invoice_no", "source_file"]
SORTABLE = {"sb_date", "fob_inr", "quantity", "exporter_name", "importer_name", "foreign_country", "hs_code"}


@app.route("/api/table")
@cached
def table():
    w, p = where()
    page = max(1, int(request.args.get("page", 1)))
    size = max(10, min(int(request.args.get("size", 50)), 200))
    sort = request.args.get("sort", "sb_date")
    sort = sort if sort in SORTABLE else "sb_date"
    direction = "ASC" if request.args.get("dir") == "asc" else "DESC"
    total = q("SELECT COUNT(*) FROM shipments" + w, p)[0][0]
    rows = q(f"SELECT {', '.join(TABLE_COLS)} FROM shipments{w} ORDER BY {sort} {direction}, id LIMIT ? OFFSET ?",
             p + [size, (page - 1) * size])
    return jsonify(total=total, page=page, size=size, columns=TABLE_COLS, rows=rows, xlsx_limit=XLSX_LIMIT)


@app.route("/api/suggest")
def suggest():
    field = request.args.get("field", "")
    text = request.args.get("q", "").strip().upper()
    if not text:
        return jsonify(items=[])
    like, starts = f"%{text}%", f"{text}%"
    if field in ("country", "port", "exporter", "importer"):
        col = {"country": "foreign_country", "port": "indian_port", "exporter": "exporter_name", "importer": "importer_name"}[field]
        rows = q(f"SELECT {col}, COUNT(*) c FROM shipments WHERE {col} LIKE ? GROUP BY {col}"
                 f" ORDER BY ({col} LIKE ?) DESC, c DESC LIMIT 15", (like, starts))
        return jsonify(items=[{"value": r[0], "label": f"{r[1]:,} records"} for r in rows])
    if field == "hs":
        if text.isdigit():
            rows = q("SELECT hs_code, COUNT(*) FROM shipments WHERE hs_code LIKE ?"
                     " GROUP BY hs_code ORDER BY COUNT(*) DESC LIMIT 12", (starts,))
            items = [{"value": r[0], "label": common_desc("hs_code", r[0])[:80]} for r in rows]
            if len(text) <= 4:
                rows4 = q("SELECT hs4 FROM shipments WHERE hs4 LIKE ? GROUP BY hs4 ORDER BY hs4 LIMIT 6", (starts,))
                items = [{"value": r[0], "label": "all codes starting " + r[0] + " - " + common_desc("hs4", r[0])[:60]} for r in rows4] + items
            return jsonify(items=items[:18])
        rows = q("SELECT hs_code, COUNT(*) FROM shipments WHERE upper(product_description) LIKE ?"
                 " GROUP BY hs_code ORDER BY COUNT(*) DESC LIMIT 10", (like,))
        return jsonify(items=[{"value": r[0], "label": common_desc("hs_code", r[0])[:80]} for r in rows])
    return jsonify(items=[])


@app.route("/api/coverage")
@cached
def coverage():
    rows = q("SELECT chapter, ym, COUNT(*), COALESCE(SUM(fob_inr),0) FROM shipments WHERE ym IS NOT NULL"
             " GROUP BY chapter, ym ORDER BY chapter, ym")
    return jsonify(rows=[{"chapter": r[0], "ym": r[1], "records": r[2], "fob": r[3]} for r in rows])


@app.route("/api/meta")
@cached
def meta():
    log = q("SELECT source_file, container, rows, imported_at FROM import_log ORDER BY imported_at DESC, source_file")
    n, mn, mx = q("SELECT COUNT(*), MIN(sb_date), MAX(sb_date) FROM shipments")[0]
    return jsonify(records=n, date_min=mn, date_max=mx, db_mb=round(DB_PATH.stat().st_size / 1e6, 1),
                   imports=[{"file": r[0], "container": r[1], "rows": r[2], "at": r[3]} for r in log])


# -------------------------------------------------------------------------------------- downloads
EXPORT_SQL = "SELECT " + ", ".join(c[0] for c in COLUMNS) + " FROM shipments"


def stamp():
    return dt.datetime.now().strftime("%Y%m%d_%H%M")


@app.route("/api/export.csv")
def export_csv():
    w, p = where()
    sql = EXPORT_SQL + w + " ORDER BY sb_date, id"

    def gen():
        con = sqlite3.connect(DB_PATH.as_uri() + "?mode=ro", uri=True)   # request connection is closed before streaming ends
        cur = con.execute(sql, p)
        buf = io.StringIO()
        wr = csv.writer(buf)
        buf.write("\ufeff")
        wr.writerow([c[1] for c in COLUMNS])
        yield buf.getvalue(); buf.seek(0); buf.truncate()
        while True:
            chunk = cur.fetchmany(5000)
            if not chunk:
                break
            wr.writerows(chunk)
            yield buf.getvalue(); buf.seek(0); buf.truncate()
        con.close()

    return Response(gen(), mimetype="text/csv",
                    headers={"Content-Disposition": f"attachment; filename=export_data_{stamp()}.csv"})


@app.route("/api/export.xlsx")
def export_xlsx():
    from openpyxl import Workbook
    w, p = where()
    n = q("SELECT COUNT(*) FROM shipments" + w, p)[0][0]
    if n > XLSX_LIMIT:
        return jsonify(error="too_many_rows", message=f"{n:,} rows is more than the Excel limit of {XLSX_LIMIT:,}. "
                       "Narrow the filters or use the CSV download."), 413
    wb = Workbook(write_only=True)
    ws = wb.create_sheet("Export Data")
    ws.append([c[1] for c in COLUMNS])
    kinds = [c[2] for c in COLUMNS]
    cur = db().execute(EXPORT_SQL + w + " ORDER BY sb_date, id", p)
    for row in cur:
        out = list(row)
        for i, k in enumerate(kinds):
            if k == "date" and out[i]:
                out[i] = dt.datetime.strptime(out[i], "%Y-%m-%d").date()
        ws.append(out)
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".xlsx")
    tmp.close()
    wb.save(tmp.name)
    resp = send_file(tmp.name, as_attachment=True, download_name=f"export_data_{stamp()}.xlsx",
                     mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    resp.call_on_close(lambda: os.path.exists(tmp.name) and os.unlink(tmp.name))
    return resp


# ------------------------------------------------------------------------------------------- start
if __name__ == "__main__":
    host, port = "127.0.0.1", int(os.environ.get("PORT", 5000))      # 127.0.0.1 = this PC only
    url = f"http://{host}:{port}"
    print(f"\n  Export Data Explorer is running at {url}\n  Close this window (or press Ctrl+C) to stop it.\n")
    if not DB_PATH.exists():
        print("  NOTE: no database found yet - run the import step first.\n")
    if os.environ.get("NO_BROWSER") != "1":
        threading.Timer(1.2, lambda: webbrowser.open(url)).start()
    app.run(host=host, port=port, threaded=True)

#!/usr/bin/env bash
cd "$(dirname "$0")"
./venv/bin/python import_data.py "$@"

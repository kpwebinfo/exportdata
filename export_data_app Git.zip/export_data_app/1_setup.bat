@echo off
setlocal
cd /d "%~dp0"
set PY=
python --version >nul 2>nul && set PY=python
if not defined PY ( py -3 --version >nul 2>nul && set PY=py -3 )
if not defined PY (
  echo.
  echo  Python was not found on this PC.
  echo    1. Download Python from https://www.python.org/downloads/
  echo    2. In the installer, TICK the box "Add python.exe to PATH"
  echo    3. Run this file again.
  echo.
  pause
  exit /b 1
)
echo Using: %PY%
if not exist "venv\Scripts\python.exe" %PY% -m venv venv
"venv\Scripts\python.exe" -m pip install --upgrade pip
"venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 (
  echo.
  echo Install failed - check your internet connection and run this file again.
  pause
  exit /b 1
)
echo.
echo Setup complete.
echo Next: put your Excel files in the folder  data\incoming  and double-click  2_import_data.bat
pause

#!/usr/bin/env bash
# Mac / Linux:  ./setup.sh   then   ./import.sh   then   ./run.sh
cd "$(dirname "$0")"
python3 -m venv venv && ./venv/bin/pip install --upgrade pip && ./venv/bin/pip install -r requirements.txt
echo "Setup complete. Put your files in data/incoming, then run ./import.sh"

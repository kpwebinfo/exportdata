"use strict";
/* Export Data Explorer - front end (no external libraries, works offline) */

const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const MONTHS = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];
const CHIP_KEYS = ["hs", "country", "port"];
const TEXT_KEYS = ["exporter", "importer", "product"];
const CHECK_KEYS = ["year", "month", "chapter", "mode"];
const LABELS = { year: "Year", month: "Month", chapter: "Chapter", mode: "Mode", hs: "HS", country: "Country",
  port: "Port", exporter: "Exporter", importer: "Buyer", product: "Product" };

const state = {
  filters: { year: [], month: [], chapter: [], mode: [], hs: [], country: [], port: [], exporter: "", importer: "", product: "" },
  tab: "overview", hsBy: "hs4", page: 1, sort: "sb_date", dir: "desc",
  rankSort: {}, rankLimit: {}, tok: 0, pending: 0,
};

/* ---------- helpers ---------- */
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const fmtInt = n => (n ?? 0).toLocaleString("en-IN");
const crore = v => (v / 1e7).toLocaleString("en-IN", { maximumFractionDigits: 2, minimumFractionDigits: 2 });
const fmtNum = (v, d = 2) => v == null ? "" : Number(v).toLocaleString("en-IN", { maximumFractionDigits: d });
const ymLabel = ym => { const [y, m] = ym.split("-"); return MONTHS[+m - 1][0] + MONTHS[+m - 1].slice(1).toLowerCase() + " " + y.slice(2); };
const debounce = (fn, ms) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };

function qs(extra = {}) {
  const p = new URLSearchParams();
  for (const [k, v] of Object.entries(state.filters)) {
    if (Array.isArray(v)) v.forEach(x => p.append(k, x)); else if (v) p.set(k, v);
  }
  for (const [k, v] of Object.entries(extra)) p.set(k, v);
  return p.toString();
}

async function api(path, extra = {}, withFilters = true) {
  state.pending++; document.body.classList.add("loading");
  try {
    const url = `/api/${path}?${withFilters ? qs(extra) : new URLSearchParams(extra).toString()}`;
    const r = await fetch(url);
    const j = await r.json();
    if (!r.ok) {
      if (j.error === "no_db") showBanner(j.message);
      throw new Error(j.message || j.error || r.statusText);
    }
    $("#banner").hidden = true;
    return j;
  } finally {
    if (--state.pending === 0) document.body.classList.remove("loading");
  }
}
function showBanner(msg) { const b = $("#banner"); b.textContent = msg; b.hidden = false; }

/* ---------- filters ---------- */
function checkGroup(key, items, label = x => x) {
  const box = $("#f-" + key);
  box.innerHTML = items.map(it => `<label><input type="checkbox" data-ck="${key}" value="${esc(it.v)}"> ${esc(label(it.v))}${it.n != null ? `<span class="n">${fmtInt(it.n)}</span>` : ""}</label>`).join("");
}

function renderChips(key) {
  $("#c-" + key).innerHTML = state.filters[key].map(v =>
    `<span class="chip">${esc(v)}<button data-rmchip="${key}" data-v="${esc(v)}" title="Remove">×</button></span>`).join("");
}

function addChip(key, val) {
  val = (val || "").trim();
  if (!val) return;
  if (key === "country" || key === "port") val = val.toUpperCase();
  if (!state.filters[key].includes(val)) state.filters[key].push(val);
  renderChips(key); refresh();
}

function setText(key, val) {
  state.filters[key] = val;
  const el = $("#in-" + key); if (el) el.value = val;
  refresh();
}

function syncUIFromState() {
  CHECK_KEYS.forEach(k => $$(`[data-ck="${k}"]`).forEach(cb => cb.checked = state.filters[k].includes(cb.value)));
  CHIP_KEYS.forEach(renderChips);
  TEXT_KEYS.forEach(k => { const el = $("#in-" + k); if (el) el.value = state.filters[k]; });
}

function resetAll() {
  for (const k of Object.keys(state.filters)) state.filters[k] = Array.isArray(state.filters[k]) ? [] : "";
  syncUIFromState(); refresh();
}

function renderActive() {
  const pills = [];
  for (const [k, v] of Object.entries(state.filters)) {
    if (Array.isArray(v)) v.forEach(x => pills.push([k, x]));
    else if (v) pills.push([k, v]);
  }
  $("#active").innerHTML = pills.map(([k, v]) =>
    `<span class="chip">${LABELS[k]}: ${esc(v)}<button data-ak="${k}" data-av="${esc(v)}" title="Remove">×</button></span>`).join("")
    + (pills.length ? `<button class="link" id="clearAll">Clear all</button>` : "");
}

function removeFilter(k, v) {
  if (Array.isArray(state.filters[k])) state.filters[k] = state.filters[k].filter(x => x !== v);
  else state.filters[k] = "";
  syncUIFromState(); refresh();
}

function setupSuggest(key, field, listId) {
  const input = $("#in-" + key), list = $("#" + listId);
  const isChip = CHIP_KEYS.includes(key);
  const fetchSug = debounce(async () => {
    let text = input.value;
    let prefix = "";
    if (!isChip && text.includes(";")) { const i = text.lastIndexOf(";"); prefix = text.slice(0, i + 1) + " "; text = text.slice(i + 1); }
    text = text.trim();
    if (text.length < 2 && !(key === "hs" && /^\d+$/.test(text))) { list.innerHTML = ""; return; }
    try {
      const j = await api("suggest", { field, q: text }, false);
      list.innerHTML = j.items.map(i => `<option value="${esc(prefix + i.value)}" label="${esc(i.label)}"></option>`).join("");
    } catch (e) { /* ignore */ }
  }, 220);
  input.addEventListener("input", e => {
    if (isChip && (!(e instanceof InputEvent) || e.inputType === "insertReplacementText")) { commit(); return; }
    if (!isChip) state.filters[key] = input.value.trim(), refreshSoon();
    fetchSug();
  });
  input.addEventListener("keydown", e => { if (e.key === "Enter" && isChip) { e.preventDefault(); commit(); } });
  async function commit() {
    const v = input.value.trim();
    let opts = [...list.options].map(o => o.value);
    input.value = ""; list.innerHTML = "";
    if (!v) return;
    if (key === "hs") {
      if (!/^\d+$/.test(v)) { setText("product", v); return; }       // words go to the product search
      addChip(key, v); return;
    }
    if (!opts.length) {                                              // pressed Enter before suggestions arrived
      try { opts = (await api("suggest", { field, q: v }, false)).items.map(i => i.value); } catch (e) { opts = []; }
    }
    const exact = opts.find(o => o.toUpperCase() === v.toUpperCase());
    const pick = exact || opts[0];                                   // partial text snaps to the best match
    if (pick) addChip(key, pick);
  }
}

/* ---------- refresh cycle ---------- */
const refreshSoon = debounce(() => refresh(), 350);
function refresh() { state.page = 1; renderActive(); loadKpis(); loadTab(state.tab); }

async function loadKpis() {
  const j = await api("kpis");
  const card = (v, l) => `<div class="kpi"><div class="v">${v}</div><div class="l">${l}</div></div>`;
  $("#kpis").innerHTML = card(fmtInt(j.records), "Records") + card("₹ " + crore(j.fob) + " Cr", "FOB value") +
    card(fmtInt(j.exporters), "Exporters") + card(fmtInt(j.importers), "Buyers") +
    card(fmtInt(j.countries), "Countries") + card(fmtInt(j.ports), "Indian ports");
}

function showTab(t) {
  state.tab = t;
  $$("#tabs button").forEach(b => b.classList.toggle("on", b.dataset.tab === t));
  $$(".tab").forEach(s => s.hidden = s.id !== "tab-" + t);
  loadTab(t);
}

function loadTab(t) {
  const tok = ++state.tok;
  const run = { overview, exporters: () => rank("rank-exporters", "exporter", "Top exporters", "Exporter", "exporter"),
    buyers: () => rank("rank-buyers", "importer", "Top buyers (importers)", "Buyer", "importer"),
    countries: () => Promise.all([rank("rank-countries", "country", "Destination countries", "Country", "country"),
                                  rank("rank-fports", "foreign_port", "Foreign (discharge) ports", "Port", null)]),
    ports: () => rank("rank-ports", "port", "Indian ports", "Port", "port"),
    products: productsTab, records, info }[t];
  return run(tok).catch(e => console.error(e));
}

/* ---------- overview ---------- */
function barList(el, rows, key, withDesc) {
  const max = Math.max(...rows.map(r => r.fob), 1);
  el.innerHTML = rows.length ? `<div class="bl">` + rows.map(r => {
    const desc = withDesc ? r.extra[r.extra.length - 1] : "";
    const label = withDesc ? `${r.name} · ${desc}` : r.name;
    return `<div class="row"><div class="nm" data-k="${key}" data-v="${esc(r.name)}" title="${esc(label)} - click to filter">${esc(label)}</div>
      <div class="track"><div class="fill" style="width:${(r.fob / max * 100).toFixed(1)}%"></div></div>
      <div class="val">₹ ${crore(r.fob)} Cr</div></div>`;
  }).join("") + `</div>` : `<div class="muted">No data for these filters.</div>`;
}

async function overview(tok) {
  const [tr, c, h, e, p] = await Promise.all([api("trend"), api("top", { by: "country", limit: 10 }),
    api("top", { by: "hs4", limit: 10 }), api("top", { by: "exporter", limit: 10 }), api("top", { by: "port", limit: 10 })]);
  if (tok !== state.tok) return;
  trendChart($("#trend"), tr.rows);
  barList($("#ov-country"), c.rows, "country");
  barList($("#ov-hs4"), h.rows, "hs", true);
  barList($("#ov-exporter"), e.rows, "exporter");
  barList($("#ov-port"), p.rows, "port");
}

function monthRange(first, last) {
  const out = []; let [y, m] = first.split("-").map(Number); const [ly, lm] = last.split("-").map(Number);
  while (y < ly || (y === ly && m <= lm)) { out.push(`${y}-${String(m).padStart(2, "0")}`); if (++m > 12) { m = 1; y++; } }
  return out;
}

function trendChart(el, rows) {
  if (!rows.length) { el.innerHTML = `<div class="muted">No dated records for these filters.</div>`; return; }
  const by = Object.fromEntries(rows.map(r => [r.ym, r]));
  const months = monthRange(rows[0].ym, rows[rows.length - 1].ym);
  const vals = months.map(m => (by[m]?.fob || 0) / 1e7);
  const rawMax = Math.max(...vals, 1), mag = Math.pow(10, Math.floor(Math.log10(rawMax)));
  const max = Math.ceil(rawMax / mag * 2) / 2 * mag;       // "nice" axis top
  const W = 900, H = 270, L = 62, R = 10, T = 12, B = 36, iw = W - L - R, ih = H - T - B, bw = iw / months.length;
  let s = `<svg viewBox="0 0 ${W} ${H}" width="100%" role="img" aria-label="FOB value by month">`;
  for (let i = 0; i <= 4; i++) {
    const y = T + ih - ih * i / 4;
    s += `<line class="gl" x1="${L}" x2="${W - R}" y1="${y}" y2="${y}"/><text x="${L - 6}" y="${y + 4}" text-anchor="end">${fmtNum(max * i / 4, 0)}</text>`;
  }
  const step = Math.ceil(months.length / 18);
  months.forEach((m, i) => {
    const r = by[m], v = vals[i], x = L + i * bw + bw * 0.15, w = bw * 0.7, h = ih * v / max;
    const [yy, mm] = m.split("-");
    if (r) s += `<rect class="bar" x="${x}" y="${T + ih - h}" width="${w}" height="${Math.max(h, 1)}" rx="2" data-y="${yy}" data-m="${MONTHS[+mm - 1]}" style="cursor:pointer"><title>${ymLabel(m)}: ₹ ${fmtNum(v)} Cr · ${fmtInt(r.records)} records (click to filter)</title></rect>`;
    else s += `<rect class="zero" x="${x}" y="${T + ih - 3}" width="${w}" height="3"><title>${ymLabel(m)}: no data</title></rect>`;
    if (i % step === 0) s += `<text x="${x + w / 2}" y="${H - 14}" text-anchor="middle">${ymLabel(m)}</text>`;
  });
  el.innerHTML = s + `</svg>` + (months.some(m => !by[m]) ? `<div class="muted">Red marks = months with no data in the database.</div>` : "");
}

/* ---------- ranking tables ---------- */
async function rank(elId, by, title, nameLabel, pickKey) {
  const tok = state.tok;
  const sort = state.rankSort[elId] || "fob", limit = state.rankLimit[elId] || 50;
  const j = await api("top", { by, limit, sort });
  if (tok !== state.tok) return;
  const el = $("#" + elId);
  const max = j.total_fob || 1;
  const head = `<th class="num">#</th><th>${nameLabel}</th><th class="num sortable" data-sort="records" data-el="${elId}">Records${sort === "records" ? " ▼" : ""}</th>
    <th class="num sortable" data-sort="fob" data-el="${elId}">FOB ₹ Cr${sort === "fob" ? " ▼" : ""}</th><th>Share</th>` + j.extra_labels.map(l => `<th class="${/^(Exporters|Countries|Buyers)$/.test(l) ? "num" : ""}">${esc(l)}</th>`).join("");
  const body = j.rows.map((r, i) => {
    const sh = r.fob / max * 100;
    const nm = pickKey ? `<td class="name" data-k="${pickKey}" data-v="${esc(r.name)}" title="Click to filter">${esc(r.name)}</td>` : `<td>${esc(r.name)}</td>`;
    return `<tr><td class="num">${i + 1}</td>${nm}<td class="num">${fmtInt(r.records)}</td><td class="num">${crore(r.fob)}</td>
      <td><span class="share" style="width:${Math.min(sh, 100) * 0.6}px"></span>${sh.toFixed(1)}%</td>` +
      r.extra.map(x => typeof x === "number" ? `<td class="num">${fmtInt(x)}</td>`
        : `<td class="${typeof x === "string" && x.length > 30 ? "wrap" : ""}" title="${esc(x)}">${esc(x)}</td>`).join("") + `</tr>`;
  }).join("");
  el.innerHTML = `<h3>${title} <span class="muted">· showing ${fmtInt(j.rows.length)} of ${fmtInt(j.groups)}</span></h3>
    <div class="scroll"><table><thead><tr>${head}</tr></thead><tbody>${body || `<tr><td colspan="9" class="muted">No data for these filters.</td></tr>`}</tbody></table></div>` +
    (j.groups > j.rows.length ? `<button class="link more" data-more="${elId}">Show 50 more</button>` : "");
}

async function productsTab(tok) {
  const by = state.hsBy;
  await rank("rank-products", by, by === "hs4" ? "Products by 4-digit HS code" : by === "hs8" ? "Products by 8-digit HS code" : "Products by description",
    by === "product" ? "Description" : "HS code", by === "product" ? "product" : "hs");
}

/* ---------- records ---------- */
const REC_LABEL = { sb_date: "Date", sb_no: "SB No.", exporter_name: "Exporter", importer_name: "Buyer", foreign_country: "Country",
  foreign_port: "Foreign port", indian_port: "Indian port", mode: "Mode", hs_code: "HS code", product_description: "Product",
  quantity: "Qty", uqc: "UQC", currency: "Cur.", unit_rate_fc: "Unit rate (FC)", fob_inr: "FOB ₹", invoice_no: "Invoice", source_file: "Source file" };
const REC_SORT = new Set(["sb_date", "fob_inr", "quantity", "exporter_name", "importer_name", "foreign_country", "hs_code"]);
const REC_NUM = new Set(["quantity", "unit_rate_fc", "fob_inr"]);
const REC_PICK = { exporter_name: "exporter", importer_name: "importer", foreign_country: "country", indian_port: "port", hs_code: "hs" };

async function records(tok) {
  const j = await api("table", { page: state.page, size: 50, sort: state.sort, dir: state.dir });
  if (tok !== state.tok) return;
  const head = j.columns.map(c => `<th class="${REC_SORT.has(c) ? "sortable" : ""} ${REC_NUM.has(c) ? "num" : ""}" data-rs="${REC_SORT.has(c) ? c : ""}">${REC_LABEL[c] || c}${state.sort === c ? (state.dir === "asc" ? " ▲" : " ▼") : ""}</th>`).join("");
  const body = j.rows.map(r => "<tr>" + r.map((v, i) => {
    const c = j.columns[i];
    if (REC_NUM.has(c)) return `<td class="num">${fmtNum(v, c === "fob_inr" ? 2 : 4)}</td>`;
    if (REC_PICK[c] && v) return `<td class="name" data-k="${REC_PICK[c]}" data-v="${esc(v)}" title="Click to filter">${esc(v)}</td>`;
    return `<td class="${c === "product_description" ? "wrap" : ""}" title="${c === "product_description" ? esc(v) : ""}">${esc(v)}</td>`;
  }).join("") + "</tr>").join("");
  $("#recTable").innerHTML = `<thead><tr>${head}</tr></thead><tbody>${body || `<tr><td class="muted">No records for these filters.</td></tr>`}</tbody>`;
  const pages = Math.max(1, Math.ceil(j.total / j.size));
  $("#recCount").textContent = `${fmtInt(j.total)} records`;
  $("#pager").innerHTML = `<button id="prev" ${j.page <= 1 ? "disabled" : ""}>‹ Prev</button><span>Page ${fmtInt(j.page)} of ${fmtInt(pages)}</span><button id="next" ${j.page >= pages ? "disabled" : ""}>Next ›</button>`;
  const ok = j.total <= j.xlsx_limit && j.total > 0;
  const x = $("#dlXlsx"); x.href = "/api/export.xlsx?" + qs(); x.classList.toggle("off", !ok);
  const c = $("#dlCsv"); c.href = "/api/export.csv?" + qs(); c.classList.toggle("off", j.total === 0);
  $("#dlHint").textContent = j.total > j.xlsx_limit
    ? `Excel download is limited to ${fmtInt(j.xlsx_limit)} rows - narrow the filters, or use CSV (note: Excel drops leading zeros of IEC when opening CSV).`
    : "Downloads include every column and all rows that match the filters, not just this page.";
}

/* ---------- data info ---------- */
async function info(tok) {
  const [cov, meta] = await Promise.all([api("coverage", {}, false), api("meta", {}, false)]);
  if (tok !== state.tok) return;
  const chapters = [...new Set(cov.rows.map(r => r.chapter))];
  let html = "";
  for (const ch of chapters) {
    const rows = cov.rows.filter(r => r.chapter === ch), have = Object.fromEntries(rows.map(r => [r.ym, r.records]));
    const yms = rows.map(r => r.ym), all = monthRange(yms[0], yms[yms.length - 1]);
    const years = [...new Set(all.map(m => m.slice(0, 4)))];
    html += `<h4>Chapter ${esc(ch)}</h4><div class="scroll"><table class="cov"><thead><tr><th>Year</th>${MONTHS.map(m => `<th>${m[0] + m.slice(1).toLowerCase()}</th>`).join("")}</tr></thead><tbody>` +
      years.map(y => `<tr><td>${y}</td>` + MONTHS.map((_, i) => {
        const ym = `${y}-${String(i + 1).padStart(2, "0")}`;
        if (!all.includes(ym)) return `<td class="muted">·</td>`;
        return have[ym] ? `<td>${fmtInt(have[ym])}</td>` : `<td class="miss" title="No data imported for this month">—</td>`;
      }).join("") + `</tr>`).join("") + `</tbody></table></div>`;
  }
  $("#coverage").innerHTML = html || `<div class="muted">No data.</div>`;
  $("#importTable").innerHTML = `<thead><tr><th>Source file</th><th class="num">Rows</th><th>Loaded from</th><th>Imported at</th></tr></thead><tbody>` +
    meta.imports.map(i => `<tr><td>${esc(i.file)}</td><td class="num">${fmtInt(i.rows)}</td><td>${esc(i.container)}</td><td>${esc(i.at)}</td></tr>`).join("") + `</tbody>`;
}

/* ---------- wiring ---------- */
document.addEventListener("click", e => {
  const t = e.target;
  let el;
  if ((el = t.closest("[data-k]"))) {
    const k = el.dataset.k, v = el.dataset.v;
    CHIP_KEYS.includes(k) ? addChip(k, v) : setText(k, v);
  } else if ((el = t.closest("[data-rmchip]"))) removeFilter(el.dataset.rmchip, el.dataset.v);
  else if ((el = t.closest("[data-ak]"))) removeFilter(el.dataset.ak, el.dataset.av);
  else if (t.id === "clearAll" || t.id === "resetBtn") resetAll();
  else if ((el = t.closest("#tabs button"))) showTab(el.dataset.tab);
  else if ((el = t.closest("#hsBy button"))) { state.hsBy = el.dataset.by; $$("#hsBy button").forEach(b => b.classList.toggle("on", b === el)); loadTab("products"); }
  else if ((el = t.closest("th[data-sort]"))) { state.rankSort[el.dataset.el] = el.dataset.sort; loadTab(state.tab); }
  else if ((el = t.closest("[data-more]"))) { const id = el.dataset.more; state.rankLimit[id] = (state.rankLimit[id] || 50) + 50; loadTab(state.tab); }
  else if ((el = t.closest("th[data-rs]")) && el.dataset.rs) {
    const c = el.dataset.rs;
    if (state.sort === c) state.dir = state.dir === "asc" ? "desc" : "asc"; else { state.sort = c; state.dir = c.endsWith("name") || c === "foreign_country" ? "asc" : "desc"; }
    state.page = 1; loadTab("records");
  } else if (t.id === "prev") { state.page--; loadTab("records"); }
  else if (t.id === "next") { state.page++; loadTab("records"); }
  else if (t.matches && t.matches("rect.bar") && t.dataset.y) {            // click a month bar -> filter to that month
    state.filters.year = [t.dataset.y]; state.filters.month = [t.dataset.m]; syncUIFromState(); refresh();
  }
});
document.addEventListener("change", e => {
  const cb = e.target.closest("[data-ck]");
  if (!cb) return;
  const k = cb.dataset.ck;
  state.filters[k] = $$(`[data-ck="${k}"]`).filter(x => x.checked).map(x => x.value);
  refresh();
});

async function init() {
  try {
    const [opt, meta] = await Promise.all([api("options", {}, false), api("meta", {}, false)]);
    checkGroup("year", opt.years); checkGroup("chapter", opt.chapters, v => "Chapter " + v);
    checkGroup("mode", opt.modes);
    checkGroup("month", MONTHS.map(m => ({ v: m })), m => m[0] + m.slice(1).toLowerCase());
    setupSuggest("hs", "hs", "dl-hs"); setupSuggest("country", "country", "dl-country"); setupSuggest("port", "port", "dl-port");
    setupSuggest("exporter", "exporter", "dl-exporter"); setupSuggest("importer", "importer", "dl-importer");
    $("#in-product").addEventListener("input", e => { state.filters.product = e.target.value.trim(); refreshSoon(); });
    $("#subtitle").textContent = `${fmtInt(meta.records)} records · ${meta.date_min} to ${meta.date_max} · ${meta.imports.length} source files · database ${meta.db_mb} MB`;
    refresh();
  } catch (e) {
    $("#subtitle").textContent = "No data loaded yet";
    console.error(e);
  }
}
init();

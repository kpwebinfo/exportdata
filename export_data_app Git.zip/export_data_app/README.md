# Export Data Explorer

A web app that runs **only on your own PC** (nothing is uploaded anywhere). It reads your export
Excel files into a local database and gives you a browser dashboard: filters, charts, rankings of
exporters / buyers / countries / ports / products, a records table, and Excel/CSV downloads.

```
export_data_app/
  1_setup.bat            run once  - installs what the app needs
  2_import_data.bat      run whenever you add files - loads them into the database
  2b_rebuild_database.bat  wipes the database and re-imports everything (rarely needed)
  3_run_app.bat          starts the app and opens your browser
  data/incoming/         <- put your Excel / CSV files here
  data/exports.db        the database (created by the import step)
  app.py  import_data.py  schema.py  static/   the program itself
```

## First-time setup (Windows)

1. **Install Python** (once): https://www.python.org/downloads/ -> run the installer and
   **tick "Add python.exe to PATH"** on the first screen.
2. **Unzip** this folder somewhere simple, e.g. `C:\export_data_app`.
3. **Copy your data** into `data\incoming`: the compiled workbook
   (`Export_Chapter17_Compiled_Jan2021_to_Jan2022.xlsx`) is the easiest start.
4. Double-click **`1_setup.bat`** (needs internet, takes 1-3 minutes, one time only).
5. Double-click **`2_import_data.bat`**. The compiled workbook takes about 2 minutes; raw monthly
   files take a few seconds each. You will see a line for every month loaded.
6. Double-click **`3_run_app.bat`**. Your browser opens at http://127.0.0.1:5000 .
   Keep the black window open while you work; close it to stop the app.

Next time, you only need step 6.

*Mac/Linux:* `./setup.sh`, then `./import.sh`, then `./run.sh`.

## Adding other HS codes and years

1. Copy the new files into `data\incoming` (any chapter, any year).
2. Double-click `2_import_data.bat`.
3. Refresh the browser page (F5).

* Files already imported are skipped, so you can leave old files in the folder.
* If you replace a file with a corrected version (same name), it is detected and its old rows are
  replaced - never duplicated. To force a re-import: `2_import_data.bat --force`.
* Raw monthly files can be in any of the header styles seen so far (SB NO / Shipping Bill No.,
  RITC / HS Code, etc.). They are cleaned the same way as the compiled workbook: placeholder text
  (NA, N/A, NULL ...) blanked, numbers and dates converted, IEC zero-padded, 4-digit HS and chapter derived.
* The **Chapter** filter on the left lets you look at one HS chapter at a time or compare chapters.
* **Data info** tab shows which months are loaded per chapter - missing months show in red.
* If the import prints `ignoring unrecognised column(s)`, the file has a header the app does not
  know. The data is still loaded; to also load that column ask for it to be added to `ALIAS` in `schema.py`.
* If it prints `required column(s) not found`, the file has no date / HS code / FOB column under a
  known name - that file is skipped and nothing else is affected.

## Using the app

* **Filters (left):** year, month, chapter, mode, HS code (type `1701`, a full 8-digit code, or a word
  like `jaggery`), destination country, Indian port, exporter, buyer, product text.
  Use `;` between names to search several at once (`sethi; kamala`). Everything on the page responds to the filters.
* **Click any name** in a table (exporter, buyer, country, port, HS code) to filter by it.
  Click a month bar on the Overview chart to zoom into that month.
* **Records** tab: sortable table, 50 per page. **Download Excel** gives every column for all rows matching
  your filters (up to 250,000 rows). For more rows use **Download CSV** - but note Excel drops leading zeros of
  IEC / bill numbers when opening a CSV, so prefer the Excel download when possible.
* Values are shown in **Indian number format**; FOB is in **Rs crore** (1 crore = 10,000,000).
* Quantities are not added up anywhere, because units differ (KGS, MTS, NOS ...).

## Good to know

* Names of exporters, buyers, countries and ports are upper-cased in the database so that "Bhutan" and
  "BHUTAN" count as one. Your Excel files are never modified.
* The same company spelled differently (e.g. "... PVT LTD" and "... PRIVATE LIMITED") still counts as two
  names. Use the `;` search to look at both together.
* Buyers named "TO ORDER" / "TO THE ORDER" are real entries in the source data (consignee not named).
* The app only listens on your own PC (127.0.0.1). Other computers on your network cannot open it.
* **Backup:** copy `data\exports.db` (the whole database is that one file) and your `data\incoming` folder.

## Using GitHub

GitHub can **store** the app (backup, version history, install on another PC) but it cannot **run** it:
GitHub Pages only hosts static pages, and this app needs its Python server and database.

**1. Keep the code on GitHub (recommended)**
1. On github.com click **New repository**, name it, and choose **Private**.
2. In this folder run:
   `git init` , `git add .` , `git commit -m "Export Data Explorer"` , then the three
   `git remote add origin ...` / `git branch -M main` / `git push -u origin main` lines GitHub shows you.
3. On any other PC: `git clone <your repo>`, then follow the normal setup steps above.

The included `.gitignore` keeps `data/` (your Excel files and the database), `*.xlsx` and `*.csv` out of the
repository. **Your data contains names, phone numbers and emails - never put it in a public repo, and avoid
committing it even to a private one.** Copy data between PCs yourself (USB / cloud drive).

**2. Run it in the cloud with GitHub Codespaces (optional)**
Open your repo on GitHub -> **Code -> Codespaces -> Create codespace**. It installs everything automatically.
In its terminal drag your files into `data/incoming`, run `python import_data.py`, then `python app.py` and
open the forwarded port 5000 (private - only you can open it). Your data then sits on GitHub's servers
inside that codespace, so use this only if that is acceptable. Free hours per month are limited.

**3. A public web link for other people** is not what this app is built for (it would expose the data). If you
need that later, it needs a login and real hosting - ask and I can plan it.

## If something goes wrong

| Problem | Fix |
|---|---|
| `Python was not found` | Install Python and tick **Add python.exe to PATH**, then rerun `1_setup.bat`. |
| Browser shows "No database yet" | Put files in `data\incoming` and run `2_import_data.bat`. |
| `Address already in use` | The app is already running in another window - close it, or open http://127.0.0.1:5000 . |
| Import says a file was skipped | It was already imported. Use `2_import_data.bat --force` to redo it. |
| Want a clean start | Run `2b_rebuild_database.bat`. |

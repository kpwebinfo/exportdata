#!/usr/bin/env python3
"""Load export-data files into the local database.

Usage
  python import_data.py                 import every NEW file found in data/incoming
  python import_data.py FILE [FILE...]  import specific files
  python import_data.py --force         re-import files even if they were imported before
  python import_data.py --reset         empty the database first, then import

Two kinds of file are understood automatically:
  1. The compiled workbook (has a sheet called "Compiled Data") - loaded as is.
  2. Raw monthly export files (any header style listed in schema.ALIAS) - cleaned the same way
     the compiled workbook was built: headers mapped, placeholders (NA, N/A, NULL ...) blanked,
     numbers and dates converted, IEC zero-padded, HS 4-digit / chapter derived.
Re-importing a file never creates duplicates: rows are keyed by their source file name.
"""
import argparse
import hashlib
import re
import sqlite3
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

from schema import (ALIAS, COLUMNS, DB_BY_DISPLAY, DB_PATH, INCOMING, KIND, PLACEHOLDERS,
                    REQUIRED, norm_header)

DISPLAY_COLS = [d for _, d, _ in COLUMNS]
UPPER_COLS = ["Exporter Names", "Importer Names", "Foreign Country", "Foreign Port", "Indian Port",
              "Mode", "Currency", "Unit Quantity", "Month"]


# --------------------------------------------------------------------------------------- helpers
def to_text(x):
    """Any cell -> stripped text, or None when empty."""
    if x is None:
        return None
    if isinstance(x, float):
        if np.isnan(x):
            return None
        return str(int(x)) if x.is_integer() else str(x)
    if isinstance(x, (int, np.integer)):
        return str(int(x))
    if hasattr(x, "strftime"):
        return x.strftime("%Y-%m-%d")
    s = str(x).strip()
    return s if s else None


def is_str(v):
    return isinstance(v, str)


def parse_dates(col):
    """Robust date parsing: real dates stay as they are, ISO text (2021-09-13) is read as ISO,
    Excel serial numbers are converted, anything else (13/09/2021) is read day-first (Indian style)."""
    col = col.astype(object)
    out = pd.Series(pd.NaT, index=col.index, dtype="datetime64[ns]")
    is_dt = col.map(lambda v: hasattr(v, "year") and hasattr(v, "month"))
    if is_dt.any():
        out[is_dt] = pd.to_datetime(col[is_dt].tolist(), errors="coerce")
    rest = ~is_dt & col.notna()
    num = rest & col.map(lambda v: isinstance(v, (int, float, np.integer, np.floating)) and not isinstance(v, bool))
    if num.any():
        out[num] = pd.to_datetime(pd.to_numeric(col[num], errors="coerce"), unit="D", origin="1899-12-30", errors="coerce")
    txt = rest & ~num
    if txt.any():
        t = col[txt].astype(str).str.strip()
        iso = pd.to_datetime(t, errors="coerce", format="ISO8601")
        left = iso.isna()
        if left.any():
            iso[left] = pd.to_datetime(t[left], errors="coerce", dayfirst=True, format="mixed")
        out[txt] = iso
    return out


def clean_text(series):
    out = series.map(to_text)
    ph = out.map(lambda v: is_str(v) and v.upper() in PLACEHOLDERS)
    return out.where(~ph, None)


def log(msg=""):
    print(msg, flush=True)


# ---------------------------------------------------------------------------------- reading files
def find_header_row(raw):
    """Index of the row that looks most like a header (handles title rows above the headers)."""
    best, best_hits = 0, -1
    for i in range(min(len(raw), 20)):
        hits = sum(1 for v in raw.iloc[i].tolist() if v is not None and norm_header(v) in ALIAS)
        if hits > best_hits:
            best, best_hits = i, hits
    return best if best_hits >= 4 else None


def read_file(path):
    """Return (dataframe_with_original_headers, kind, header_row_index)."""
    suffix = path.suffix.lower()
    if suffix == ".csv":
        try:
            raw = pd.read_csv(path, dtype=object, header=None, encoding="utf-8-sig")
        except UnicodeDecodeError:
            raw = pd.read_csv(path, dtype=object, header=None, encoding="latin-1")
        sheet = None
    else:
        xl = pd.ExcelFile(path)
        if "Compiled Data" in xl.sheet_names:
            log("  reading the compiled workbook - this can take a minute or two for big files ...")
            return pd.read_excel(xl, sheet_name="Compiled Data", dtype=object), "compiled", 0
        sheet = xl.sheet_names[0]
        raw = pd.read_excel(xl, sheet_name=sheet, dtype=object, header=None)
    h = find_header_row(raw)
    if h is None:
        raise ValueError("could not find a header row (fewer than 4 recognised column names in the first 20 rows)")
    d = raw.iloc[h + 1:].copy()
    cols, seen = [], {}
    for c in raw.iloc[h].tolist():
        c = "" if c is None or (isinstance(c, float) and np.isnan(c)) else str(c).strip()
        n = seen.get(c, 0)
        seen[c] = n + 1
        cols.append(c if n == 0 else f"{c}.{n}" if n else c)
    d.columns = cols
    d = d.reset_index(drop=True)
    d = d.dropna(how="all")
    return d, "raw", h + 2     # excel row of the first data row


# ------------------------------------------------------------------------------ cleaning raw files
def clean_raw(d, fname, first_excel_row):
    raw_cols = list(d.columns)
    src = {}
    unknown = []
    for rc in raw_cols:
        n = norm_header(rc)
        if n in ALIAS:
            src.setdefault(ALIAS[n], []).append(rc)
        elif n:
            unknown.append(rc)
    if unknown:
        log(f"  ! ignoring {len(unknown)} unrecognised column(s): {unknown}")
        log("    (add them to ALIAS in schema.py if you want them imported)")
    missing = [r for r in REQUIRED if r not in src]
    if missing:
        raise ValueError(f"required column(s) not found: {missing}. Headers in the file: {raw_cols}")
    for rc in src.get("_ignore", []):
        if d[rc].notna().any():
            log(f"  ! column '{rc}' is not empty but is being ignored")

    out = pd.DataFrame(index=d.index)
    for disp in DISPLAY_COLS:
        if disp.startswith("Source") or disp == "Data Notes":
            continue
        if disp in ("Exporter Address & state", "Exporter PIN"):
            continue
        if disp in src:
            col = d[src[disp][0]]
            kind = KIND[disp]
            if kind == "num":
                out[disp] = pd.to_numeric(col, errors="coerce")
            elif kind == "date":
                out[disp] = parse_dates(col)
            elif kind == "int":
                out[disp] = pd.to_numeric(col, errors="coerce")
            else:
                out[disp] = clean_text(col)
        else:
            out[disp] = None

    # exporter address: join address + city/state (+ the state, when it sits in a mislabelled PIN column)
    pin_state = pin_real = None
    if "_pin" in src:
        p = d[src["_pin"][0]].map(to_text)
        nn = p.dropna()
        if len(nn) and nn.str.contains(r"[A-Za-z]").mean() > 0.5:
            pin_state = p
        elif len(nn):
            pin_real = p
    out["Exporter PIN"] = pin_real
    if "_addr_full" in src:
        out["Exporter Address & state"] = clean_text(d[src["_addr_full"][0]])
    else:
        parts = [clean_text(d[src[k][0]]) for k in ("_addr_part", "_city_state") if k in src]
        if pin_state is not None:
            parts.append(clean_text(pin_state))
        if parts:
            tmp = pd.concat(parts, axis=1)
            out["Exporter Address & state"] = tmp.apply(
                lambda r: ", ".join(x for x in r.tolist() if is_str(x) and x) or None, axis=1)
        else:
            out["Exporter Address & state"] = None

    # identifiers as text
    for disp in ("Shipping Bill No.", "HS Code", "4 Digit HS Code", "Chapter", "IEC"):
        if disp in src:
            out[disp] = d[src[disp][0]].map(to_text)
    out["HS Code"] = out["HS Code"].map(lambda v: re.sub(r"\.0$", "", v) if is_str(v) else v)

    notes = pd.Series("", index=d.index)
    iec = out["IEC"]
    pad = iec.map(lambda v: is_str(v) and v.isdigit() and len(v) < 10)
    out["IEC"] = iec.where(~pad, iec.map(lambda v: v.zfill(10) if is_str(v) else v))
    notes[pad] += "IEC zero-padded to 10 digits; "
    out["Data Notes"] = notes.str.strip().str.rstrip(";").replace("", None)
    out["Source File"] = fname
    out["Source Row"] = (np.arange(len(d)) + first_excel_row).astype("int64")
    return out


# ------------------------------------------------------------------------------ final shaping
def finalize(df):
    """Make a frame with display-name columns ready for the database."""
    for disp in DISPLAY_COLS:
        if disp not in df.columns:
            df[disp] = None
    df = df[DISPLAY_COLS].copy()
    dates = parse_dates(df["Shipping Bill Date"])
    bad = int(dates.isna().sum())
    if bad:
        log(f"  ! {bad} row(s) have an unreadable Shipping Bill Date (kept, but excluded from month views)")
    df["Shipping Bill Date"] = dates.dt.strftime("%Y-%m-%d")
    for disp in DISPLAY_COLS:
        k = KIND[disp]
        if k == "text":
            df[disp] = df[disp].map(to_text)
        elif k == "num":
            df[disp] = pd.to_numeric(df[disp], errors="coerce")
    for disp in UPPER_COLS:
        df[disp] = df[disp].map(lambda v: v.upper() if is_str(v) else None)
    df["Month"] = dates.dt.strftime("%b").str.upper().where(dates.notna(), df["Month"])
    df["Year"] = dates.dt.year.astype("Float64")
    hs = df["HS Code"]
    df["4 Digit HS Code"] = df["4 Digit HS Code"].where(df["4 Digit HS Code"].notna(), hs.str[:4])
    df["Chapter"] = df["Chapter"].where(df["Chapter"].notna(), hs.str[:2])
    df["Source Row"] = pd.to_numeric(df["Source Row"], errors="coerce").astype("Float64")
    df["ym"] = dates.dt.strftime("%Y-%m")
    return df


# ----------------------------------------------------------------------------------- database
def ddl():
    types = {"text": "TEXT", "date": "TEXT", "int": "INTEGER", "num": "REAL"}
    cols = ",\n  ".join(f"{db} {types[k]}" for db, _, k in COLUMNS)
    return f"""CREATE TABLE IF NOT EXISTS shipments (
  id INTEGER PRIMARY KEY,
  {cols},
  ym TEXT
);
CREATE TABLE IF NOT EXISTS import_log (
  source_file TEXT PRIMARY KEY, container TEXT, file_hash TEXT, rows INTEGER, imported_at TEXT
);"""


INDEXES = ["ym", "year", "chapter", "hs4", "hs_code", "foreign_country", "indian_port", "exporter_name",
           "importer_name", "mode", "source_file", "sb_date"]


def connect():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.executescript(ddl())
    return conn


def file_hash(path):
    h = hashlib.sha1()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def insert_frame(conn, df, container, fhash):
    db_cols = [DB_BY_DISPLAY[d] for d in DISPLAY_COLS] + ["ym"]
    sql = f"INSERT INTO shipments ({','.join(db_cols)}) VALUES ({','.join('?' * len(db_cols))})"
    total = 0
    for sf, g in df.groupby("Source File", sort=False):
        conn.execute("DELETE FROM shipments WHERE source_file = ?", (sf,))
        rows = g[DISPLAY_COLS + ["ym"]].astype(object).where(g[DISPLAY_COLS + ["ym"]].notna(), None).values.tolist()
        for r in rows:
            for i, v in enumerate(r):
                if isinstance(v, (np.integer,)):
                    r[i] = int(v)
                elif isinstance(v, (np.floating,)):
                    r[i] = float(v)
        conn.executemany(sql, rows)
        conn.execute("INSERT OR REPLACE INTO import_log VALUES (?,?,?,?,?)",
                     (sf, container, fhash, len(rows), time.strftime("%Y-%m-%d %H:%M:%S")))
        total += len(rows)
        log(f"  stored {len(rows):>8,} rows from  {sf}")
    conn.commit()
    return total


def build_indexes(conn):
    log("Building indexes (makes the app fast) ...")
    for c in INDEXES:
        conn.execute(f"CREATE INDEX IF NOT EXISTS ix_{c} ON shipments({c})")
    conn.execute("ANALYZE")
    conn.commit()


# ---------------------------------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("files", nargs="*", help="files to import (default: everything in data/incoming)")
    ap.add_argument("--force", action="store_true", help="re-import files that were imported before")
    ap.add_argument("--reset", action="store_true", help="empty the database before importing")
    a = ap.parse_args()

    if a.reset and DB_PATH.exists():
        DB_PATH.unlink()
        log("Database emptied.")
    if a.files:
        files = [Path(f) for f in a.files]
    else:
        INCOMING.mkdir(parents=True, exist_ok=True)
        files = sorted(p for p in INCOMING.iterdir()
                       if p.suffix.lower() in (".xlsx", ".xlsm", ".csv") and not p.name.startswith("~$"))
    if not files:
        log(f"No files found. Put your Excel/CSV files in:\n  {INCOMING}")
        return 1

    conn = connect()
    done = {r[0] for r in conn.execute("SELECT DISTINCT file_hash FROM import_log")}
    imported = failed = skipped = 0
    for p in files:
        log(f"\n=== {p.name}")
        if not p.exists():
            log("  ! file not found"); failed += 1; continue
        fh = file_hash(p)
        if fh in done and not a.force:
            log("  already imported (same file contents) - skipped. Use --force to re-import.")
            skipped += 1
            continue
        t0 = time.time()
        try:
            d, kind, first_row = read_file(p)
            if kind == "compiled":
                d = d.rename(columns={c: str(c).strip() for c in d.columns})
                if "Source File" not in d.columns or d["Source File"].isna().all():
                    d["Source File"] = p.name
                log(f"  compiled workbook: {len(d):,} rows")
            else:
                log(f"  raw file: {len(d):,} rows, {len(d.columns)} columns")
                d = clean_raw(d, p.name, first_row)
            df = finalize(d)
            imported += insert_frame(conn, df, p.name, fh)
            log(f"  done in {time.time() - t0:.0f}s")
        except Exception as e:           # keep going with the other files
            failed += 1
            log(f"  ! FAILED: {e}")
    if imported:
        build_indexes(conn)
    n, = conn.execute("SELECT COUNT(*) FROM shipments").fetchone()
    log(f"\nFinished. Imported {imported:,} rows, {skipped} file(s) skipped, {failed} failed. "
        f"Database now holds {n:,} rows.")
    conn.close()
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())

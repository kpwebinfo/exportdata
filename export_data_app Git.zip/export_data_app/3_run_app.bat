@echo off
cd /d "%~dp0"
if not exist "venv\Scripts\python.exe" ( echo Please run 1_setup.bat first. & pause & exit /b 1 )
echo Starting Export Data Explorer - your browser will open automatically.
echo Keep this window open while you use the app. Close it to stop the app.
"venv\Scripts\python.exe" app.py
pause
